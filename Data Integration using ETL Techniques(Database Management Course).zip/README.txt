Data Integration using ETL Techniques(Database Management Course)
May 2019 � August 2019

�Loaded database from Server (ORACLE) database to local database.
�Created process to validate and load file into central repository.If null were there then it will be 
rejected and generate csv file with rejected records.
�Made the STAR schema which was grain of the all the tables and put whole database into STAR 
schema from central repository.
�Generated different views like average and sum by different fields.