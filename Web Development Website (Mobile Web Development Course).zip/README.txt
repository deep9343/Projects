Web Development Website (Mobile Web Development Course)
May 2019 � August 2019

Link:  https://onkardeep.000webhostapp.com/

�It explains JavaScript, JQuery, XML, JSON Languages
�JavaScript used for making JavaScript section, JQuery used for making JQuery part and same for others
�It�s having code explanations with simple illustrations of how to use it. 
�Visitor can execute computer code experimentally for better understanding