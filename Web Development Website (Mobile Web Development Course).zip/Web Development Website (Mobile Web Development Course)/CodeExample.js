//Basics in JavaScript

//Variable declaration
var name = 'Onkar';
var name2 = "Kunal";
var cost = 2.2;
var isGood = false;
var mixedArray = ['Donut',true,34];



//Manupulating DOM
var uname;
var pass;

uname = document.getElementById('uname').value;
pass = document.getElementById('pass').value;

var result = document.getElementById('result');
result.value = "Login Successful";

//function delaration
print(){
	console.log('Hello There!');
}

addNum(n1, n2){
	return n1+n2;
}

//ES6 function declaration
const square = (n1) => {
	return n1*n1;
}



