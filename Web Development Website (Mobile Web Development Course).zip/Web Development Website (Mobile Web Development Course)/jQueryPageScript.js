$(document).ready(function(){
	$("#btnBackground").click(function(){
				console.log("clicked");
				var red = Math.floor(Math.random() * 255) + 1;
				var green = Math.floor(Math.random() * 255) + 1;
				var blue = Math.floor(Math.random() * 255) + 1;
				var bgcolor =  "rgb("+red+", "+green+", "+blue+")";
				$("#example1Container").css("background-color",bgcolor);
			});



	$("#showExplanation1").click(function()
			{
				$("#divCodeExplanaton1").animate({
					height: 'toggle'
				})

			});

	$("#showExplanation2").click(function()
			{
				$("#divCodeExplanaton2").animate({
					height: 'toggle'
				})

			});

	$("#showExplanation3").click(function()
			{
				$("#divCodeExplanaton3").animate({
					height: 'toggle'
				})

			});

	$("#showExplanation4").click(function()
			{
				$("#divCodeExplanaton4").animate({
					height: 'toggle'
				})

			});

	$("#showExplanation5").click(function()
			{
				$("#divCodeExplanaton5").animate({
					height: 'toggle'
				})

			});

		$("#btnToggleImage").click(function()
			{
				$("#imgToggleImage").animate({
					height: 'toggle'
				})

			});

		$(".smallHead:nth(2)").click(function(){
				$(this).hide();
			});

			$(".smallHead:even").click(function(){
				$(this).css("color", 'red').css("fontWeight", "bold");
			});

		$("#appendbtn").click(function(){
				$("#example4Container").append("<h5 class='ex4'>I am new here</h5>")
			});

		$("#removebtn").click(function(){
			console.log("remove btn");
			$(".ex4:nth(0)").remove();
		});

		$("#animatebtn").mouseover(function(){
				$("#ex5Div").animate({
					top: '50px',
					left: '100px',
				});
			});
			$("#animatebtn").mouseout(function(){
				$("#ex5Div").animate({
					top: '10px',
					left: '0px',
				});
			});
	});

	$("#showJS1").click(function()
			{
				$("#divCodeJS1").animate({
					height: 'toggle'
				})

			});


	$("#showJS2").click(function()
			{
				$("#divCodeJS2").animate({
					height: 'toggle'
				})

			});

	$("#showJS3").click(function()
		{
			$("#divCodeJS3").animate({
				height: 'toggle'
			})

		});