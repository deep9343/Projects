//ALL the show explanations will be derived from jQueryPageScript.js

$(document).ready(function(){

	$("#readXML").click(function(){
		var company = document.getElementById("xml_code_example1");
		var employee = company.getElementsByTagName("employee");
		var id = company.getElementsByTagName("id")[0].firstChild.data;
		var name = company.getElementsByTagName("name")[0].firstChild.data;
		var dept = company.getElementsByTagName("dept")[0].firstChild.data;
		var address = company.getElementsByTagName("address")[0].firstChild.data;
		$("#example1h5").html("Employee <br/> Id: " + id + 
								"<br/> Name: " + name + 
								"<br/> Department: " + dept +
								"<br/> Address: " + address);
	});

	//$("#btnSearchEmployee").click(function(){readXML();});
	$("#empSearchInput").on('input', function(){
		readXML();
		console.log("value changed");
	});

	$("#example3xmlEmpNameAdd").click(function(){
		var name = $('#example3xmlEmpName').val();
		if(name == "")
			return;
		$('#example3xml').append("&nbsp;&nbsp;&nbsp&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &lt;employee&gt; <br>" + 
								 "&nbsp;&nbsp;&nbsp&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &lt;name&gt;" + name +"&lt;/name&gt; <br>" +
				   		 	     "&nbsp;&nbsp;&nbsp&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; &lt;/employee&gt; <br>");
		$('#example3xmlEmpName').val("");
	});


	function readXML(){
			var userInput = document.getElementById("empSearchInput").value;
			var info = '';
			if(userInput == null || userInput == ""){
				//alert("Please enter an Id to Search for");
				document.getElementById("xml_example2_output").innerHTML = ""; 
				return;
			}
			var company = document.getElementById('xml_code_example2'); //root note of XML
			var employees = company.getElementsByTagName('employee');
			var employeeIndex = -1;
			var id;
			//finding the employee with the given id
			for(var i = 0; i < employees.length; i++){
				id = employees[i].getElementsByTagName("id")[0].firstChild.data;
				if(id.toLowerCase().includes(userInput.toLowerCase())){
					employeeIndex = i;
					var name = employees[employeeIndex].getElementsByTagName("name")[0].firstChild.data;
					var address = employees[employeeIndex].getElementsByTagName("address")[0].firstChild.data;
					var dept = employees[employeeIndex].getElementsByTagName("dept")[0].firstChild.data;

					info += 'Employee <br/>' +
					   'Id: ' + id + '<br/>' +
					   'Name: ' + name + '<br/>' +
					   'Dept: ' + dept + '<br/>' + 
					   'Address: ' + address + '<br/><hr>';
				}
			}

			if(employeeIndex == -1){
				info = "Sorry, no such employee works here!!";
			}			
			document.getElementById("xml_example2_output").innerHTML = info;  //output
		}
});