var menuBtn = document.getElementById('menu_controller_button');
var mobileMenu = document.getElementById('div_mobile_menu');
var isOpen = false;

function toggleMenu(){
	console.log("btn clicked");
	if(!isOpen){
		mobileMenu.style.display = "block";
	}else{
		mobileMenu.style.display = "none";
	}
	isOpen = !isOpen;
}

	window.addEventListener("resize", function(event) {
		if(window.innerWidth > 600)
			mobileMenu.style.display = "none";

	});
