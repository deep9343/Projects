//Bubble Sort and Selection Sort have 3 files 
//App.c(contain main method),Sorting.h(contain headers),Sorting.c(contain method implementation)

#include "Sorting.h"
#include "Sorting.c"
#include <stdio.h>
#include <assert.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>
#define OUTPUT 0

char* executionTime(int,int,int,int,int,int);

int main(void){
//int size=7;
//int array[]={13,8,3,4,38,6,9};

double time_spent = 0.0;
clock_t begin = clock();
int size =100;
int array[size];
for (int i =0; i<size;i++){
array[i] =rand()%size+1;
}

//bubbleSort(array,size);
selectionSort(array,size);
//quickSort(array,size);
//heapSort(array,size);
clock_t end = clock();
time_spent += (double)(end - begin) / CLOCKS_PER_SEC;
printf("\nTime elpased is %f seconds\n", time_spent);
return 0;
}
