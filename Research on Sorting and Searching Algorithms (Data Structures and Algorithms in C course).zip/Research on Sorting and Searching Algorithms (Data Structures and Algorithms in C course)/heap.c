#include<stdio.h>
#include<conio.h>
#include<stdlib.h>
#include <time.h>

    void iterateDownHeap(int numbers[], int root, int bottom)//iterates down,extracts max child and swaps max with root
    {
      int done, maxChild, temp;// done represents a node that has already been checked for heap property

      done = 0;// Note : left child = 2i, right child=2i + 1 for parent at i
      while ((root*2 <= bottom) && (!done))//this loop iterates by swapping maxchild with root and then iterating over the subtree of maxchild in the same manner
      {
        if (root*2 == bottom)//Note: bottom represents the index of last element of array representing heap i.e. //the bottommost element of heap
          maxChild = root * 2;
        else if (numbers[root * 2] > numbers[root * 2 + 1])
          maxChild = root * 2;
        else
          maxChild = root * 2 + 1;

        if (numbers[root] < numbers[maxChild])//max child is the largest child that needs to be swapped with root
        {
          temp = numbers[root];
          numbers[root] = numbers[maxChild];
          numbers[maxChild] = temp;
          root = maxChild;// the swapped root element i.e. new maxchild is checked for satisfying the heap property
        }
        else
          done = 1;
      }
    }



    void heapSort(int numbers[], int array_size)
    {
      int i, temp;

      for (i = (array_size / 2)-1; i >= 0; i--)//build heap
        iterateDownHeap(numbers, i, array_size);

      for (i = array_size-1; i >= 1; i--)//sort heap by exchanging root(max) element of heap with first element of heap
      {
        temp = numbers[0];
        numbers[0] = numbers[i];
        numbers[i] = temp;
        iterateDownHeap(numbers, 0, i-1);
      }
    }




int main()
{
    double time_spent = 0.0;

	clock_t begin = clock();
	
    srand(time(NULL));
    int i;
    const int max_size=100;
    int A[max_size];
    for(i=0;i<=max_size;i++)
    {
                           A[i]=0 + rand()%(max_size-1);
                           
    }
    
                           
    
    
    heapSort(A,max_size);
    
      
    clock_t end = clock();




    
    
    for(i=0;i<max_size;i++)
                     printf("%d\n",A[i]);
    getch();
    
    	// calculate elapsed time by finding difference (end - begin) and
	// dividing the difference by CLOCKS_PER_SEC to convert to seconds
	time_spent += (double)(end - begin) / CLOCKS_PER_SEC;

	printf("\n\nTime elpased is %f seconds", time_spent);
    return 0;
}
