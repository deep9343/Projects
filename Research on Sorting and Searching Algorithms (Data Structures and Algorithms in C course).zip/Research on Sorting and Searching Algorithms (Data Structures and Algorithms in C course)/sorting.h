#include <stdio.h>
#include <assert.h>
#include <stdlib.h>
#include <string.h>
#define OUTPUT 0

void bubbleSort(int array[], int size);
void selectionSort(int array[], int size);
//void quickSort(int array[], int size);
//void heapSort(int array[], int size);
