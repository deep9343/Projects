#include "Sorting.h"
#include <stdio.h>
#include <assert.h>
#include <stdlib.h>
#include <string.h>
#define OUTPUT 0

void bubbleSort(int array[], int size){
        for(int i=0; i<size-1; i++){
                for(int j=0; j<size-1; j++){
                        if(array[j] > array[j+1]){
                                int tmp = array[j];
                                array[j] = array[j+1];
                                array[j+1] = tmp;
                        }
                }
        }
        for(int i = 0; i < size; i++){
                printf("%d ", array[i]);
        }
        printf("\n");
}




void selectionSort(int array[], int size){
        for(int marker = 0; marker < size - 1; marker++){
                int smallestIndex = marker + 1;
                int i = marker + 1;
                // find smallest
                while(i<size-1){
                        if(array[smallestIndex] > array[i+1]){
                                smallestIndex = i+1;
                        }
                        i++;
                }
                if(array[marker] > array[smallestIndex]){
                        int tmp = array[marker];
                        array[marker] = array[smallestIndex];
                        array[smallestIndex] = tmp;
                }
        }
        for(int i = 0; i < size; i++){
                printf("%d ", array[i]);
        }
        printf("\n");
}

