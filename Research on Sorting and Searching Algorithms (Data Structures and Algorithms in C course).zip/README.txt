Research on Sorting and Searching Algorithms (Data Structures and Algorithms in C course)
May 2019 � August 2019

�Researched on Bubble Sort, Selection Sort, Heap Sort, Quick Sort, Insertion Sort.
�In addition to that we also learn on Linear Search, Binary Search 
�For all the algorithms we made working code from pseudo code.We noted the timings for 1 to 10 
millions different nos.Then we compare it with different algorithm's same input nos output timings.
�We calculated run time complexity and big O complexity for each algorithms