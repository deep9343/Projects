Library Book Finder (Bachelor�s Final project)
June 2016 � May 2017

�Created desktop application as well as hardware for automation of a library
�User can order books online and automatically book will come to the library desk 
�Used C and C# Languages and Mechanical tools

Note:
�Please see the Presentation for better understanding as its
having project's videos.
�Report contains code of the project.
