    package finalproject;
    /*

     * To change this license header, choose License Headers in Project Properties.
     * To change this template file, choose Tools | Templates
     * and open the template in the editor.
     */

    import static finalproject.Filing.readString;
    import java.io.BufferedWriter;
import java.io.File;
    import java.io.FileWriter;
    import java.io.PrintWriter;
    import java.io.RandomAccessFile;
    import java.text.DateFormat;
    import java.text.SimpleDateFormat;
    import java.util.Date;
    import javafx.application.Application;
    import javafx.event.ActionEvent;
    import javafx.event.EventHandler;
    import javafx.geometry.HPos;
    import javafx.geometry.Insets;
    import javafx.geometry.Pos;
    import javafx.scene.Node;
    import javafx.scene.Scene;
    import javafx.scene.control.Alert;
    import javafx.scene.control.Button;
    import javafx.scene.control.CheckBox;
    import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
    import javafx.scene.control.TextField;
    import javafx.scene.control.TextInputDialog;
import javafx.scene.control.ToggleGroup;
    import javafx.scene.layout.ColumnConstraints;
    import javafx.scene.layout.GridPane;
    import javafx.scene.layout.RowConstraints;
    import javafx.scene.layout.StackPane;
    import javafx.scene.text.TextAlignment;
    import javafx.stage.Stage;

    /**
     *
     * @author ashuc
     */
    public class GUI extends Application {
        private Button btnLogin=new Button("Log in");
        private TextField txtUsername=new TextField();
        private TextField txtPassword=new TextField();
        private Label lblTitle=new Label("Please LOGIN to continue: ");
        private Label lblUsername=new Label("Enter Username: ");
        private Label lblPassword=new Label("Enter Password: ");

        @Override
        public void start(Stage primaryStage) {
            GridPane pane=new GridPane();

            pane.add(lblTitle, 0,0,2,1);    
            pane.add(lblUsername,0,1,1,1);
            pane.add(lblPassword,0,2,1,1);
            pane.add(txtUsername,1,1,1,1);
            pane.add(txtPassword,1,2,1,1);
            pane.add(btnLogin,1,3,1,1);
            lblTitle.setStyle("-fx-font:14pt sans-serif");
            pane.setHgap(5);
            pane.setVgap(5);
            Insets inset=new Insets(5);
            pane.setPadding(inset);
            pane.setPrefSize(300,100);
            Scene scene=new Scene(pane);

            primaryStage.setTitle("Welcome to Liquor Store");
            primaryStage.setScene(scene);
            primaryStage.show();
            Alert alertCredentials=new Alert(Alert.AlertType.INFORMATION);
            alertCredentials.setContentText("Username and Password is: "
                    + "ashuchadha");
            alertCredentials.setHeaderText("Information for MM");
            alertCredentials.show();

            btnLogin.setOnAction(new EventHandler<ActionEvent>(){
        public void handle(ActionEvent e){
            if(txtUsername.getText().equalsIgnoreCase("ashuchadha") && 
                    txtPassword.getText().equalsIgnoreCase("ashuchadha")){
                GridPane pane1=new GridPane();
                Stage stage1=new Stage();
                Label lblTitle=new Label("Choose a bottle to know its details and availability : ");
                Button btnAlcohol1=new Button("NF Screech");
                Button btnAlcohol2=new Button("Bloody Ceaser");
                Button btnAlcohol3=new Button("Molson Beer");
                Button btnAlcohol4=new Button("Yukon Jack");
                Button btnAlcohol5=new Button("Rev");
                Button btnAlcohol6=new Button("Ice Wine");
                Button btnAlcohol7=new Button("Raymond Messey");
                Button btnAlcohol8=new Button("Jameson");
                Button btnAlcohol9=new Button("Crown Royal");
                //styling buttons
               btnAlcohol1.setPrefSize(130,150);
               btnAlcohol2.setPrefSize(130,150);
               btnAlcohol3.setPrefSize(130,150);
               btnAlcohol4.setPrefSize(130,150);
               btnAlcohol5.setPrefSize(130,150);
               btnAlcohol6.setPrefSize(130,150);
               btnAlcohol7.setPrefSize(130,150);
               btnAlcohol8.setPrefSize(130,150);
               btnAlcohol9.setPrefSize(130,150);
               lblTitle.setStyle("-fx-font:12pt verdana");
                pane1.add(lblTitle,0,0,4,1);
                pane1.add(btnAlcohol1,  1,1,1,3);
                pane1.add(btnAlcohol2,  2,1,1,3);
                pane1.add(btnAlcohol3,  3,1,1,3);
                pane1.add(btnAlcohol4,  1,4,1,3);
                pane1.add(btnAlcohol5,  2,4,1,3);
                pane1.add(btnAlcohol6,  3,4,1,3);
                pane1.add(btnAlcohol7,  1,7,1,3);
                pane1.add(btnAlcohol8,  2,7,1,3);
                pane1.add(btnAlcohol9,  3,7,1,3);
                pane1.setPrefSize(600,300);
                Scene scene1=new Scene(pane1);
                //String css=this.getClass().getResource("stylesheet.css").toExternalForm();
                //scene1.getStylesheets().add(css);
                RowConstraints r010=new RowConstraints();
                RowConstraints r123456789=new RowConstraints();
                r010.setPercentHeight(12);
                r123456789.setPercentHeight(8);

                pane1.getRowConstraints().addAll(r010,r123456789,r123456789,r123456789,
                        r123456789,r123456789,r123456789,r123456789,r123456789,r123456789,r010);
                ColumnConstraints c0=new ColumnConstraints();
                ColumnConstraints c123=new ColumnConstraints();
                ColumnConstraints c4=new ColumnConstraints();
                c0.setPercentWidth(20);
                c123.setPercentWidth(30);
                c4.setPercentWidth(40);
                pane1.getColumnConstraints().addAll(c0,c123,c123,c123,c4);
                stage1.setTitle("Types of Liquor Available");
                stage1.setScene(scene1);
                stage1.show();
                primaryStage.close();
                RadioButton rdLiquorId=new RadioButton("ID");
                rdLiquorId.setSelected(true);
                GridPane.setHalignment(rdLiquorId,HPos.RIGHT);
                ToggleGroup toggle=new ToggleGroup();
                rdLiquorId.setToggleGroup(toggle);
                TextField txtSearch=new TextField();
                txtSearch.setPromptText("Search");
                pane1.add(txtSearch,4,0,1,1);
                txtSearch.setOnAction(new EventHandler<ActionEvent>(){
                    public void handle(ActionEvent e){
                 if(rdLiquorId.isSelected()){
                        //txtSearch.getText(); 
                           File file=new File("data/products.txt");
                           try{
                            RandomAccessFile raf=new RandomAccessFile(file,"rw");
                            raf.seek(Record.SIZE_REC*(Integer.parseInt(txtSearch.getText()))-1);
                         
                            Alert alertSearch=new Alert(Alert.AlertType.INFORMATION);
                   alertSearch.setContentText(readString(raf,Record.SIZE_REC,true));
                   alertSearch.setHeaderText("According to the search, we found:");
                   alertSearch.show();
                   
                        }
                           catch(Exception x){
                            Alert alertError=new Alert(Alert.AlertType.ERROR);
                   alertError.setContentText(x.getMessage());
                   alertError.setHeaderText("No data found");
                   alertError.show();   
                           }
                        
                 } //end if
                    }
                });//end txtSearch processing
                 
                
                Label lblFilter=new Label("Filter by: ");
              //  lblFilter.setTextAlignment(TextAlignment.CENTER);
                pane1.add(lblFilter,4,1,1,1);
                 GridPane.setHalignment(lblFilter,HPos.RIGHT);
              //  CheckBox chkAvailability=new CheckBox("Availability");
                pane1.add(rdLiquorId,4,2,1,1);
             
             //   pane1.add(chkAvailability,4,4,1,1);
                Label lblRateUs=new Label("Rate Us: ");
                TextField txtRateUs=new TextField();
                pane1.add(lblRateUs,0,9,1,1);
                pane1.add(txtRateUs,0,10,1,1);
                txtRateUs.setPromptText("out of 5");
                Button btnExit=new Button("Exit");
                pane1.add(btnExit,4,10,1,1);
                 GridPane.setHalignment(btnExit,HPos.CENTER);
                btnExit.setPrefSize(60,10);
                btnExit.setOnAction(new EventHandler<ActionEvent>(){
                    public void handle(ActionEvent e){
                        System.exit(0);
                    }
                });//end btnExit processing
                btnAlcohol1.setOnAction(new EventHandler<ActionEvent>(){
                    public void handle(ActionEvent e){
        Stage stage3=new Stage();
        GridPane pane3=new GridPane();
        try{
        RandomAccessFile raf=new RandomAccessFile("data/products.txt","rw");
        raf.seek(0);
        Label lblInforTitle=new Label("Detailed Information: ");
        pane3.add(lblInforTitle,0,0,2,1);
        Label lblName=new Label("The alcohol Name is: ");
        pane3.add(lblName,1,1,1,1);
        Label lblQuantity=new Label("The alcohol Quantity is: ");
        pane3.add(lblQuantity,1,2,1,1);
        Label lblPrice=new Label("The alcohol Price is: ");
        pane3.add(lblPrice,1,3,1,1);
        Label lblLocation=new Label("The alcohol Location is: ");
        pane3.add(lblLocation,1,4,1,1);
        Label lblId=new Label("The alcohol ID is: ");
        pane3.add(lblId,1,5,1,1);
        Label lblYear=new Label("The alcohol Manufactured Year is: ");
        pane3.add(lblYear,1,6,1,1);
        Label lblType=new Label("The alcohol Container Type is: ");
        pane3.add(lblType,1,7,1,1);
        Label lblNameAlcohol1=new Label(readString(raf, Record.SIZE_NME, false));
        pane3.add(lblNameAlcohol1,2,1,1,1);
        Label lblQuantityAlcohol1=new Label(String.valueOf(raf.readDouble()+"   "));
        pane3.add(lblQuantityAlcohol1,2,2,1,1);
        Label lblPriceAlcohol1=new Label(String.valueOf(raf.readDouble()+"   "));
        pane3.add(lblPriceAlcohol1,2,3,1,1);
        Label lblLocationAlcohol1=new Label(readString(raf, Record.SIZE_LOCN, false));
        pane3.add(lblLocationAlcohol1,2,4,1,1);
        Label lblIdAlcohol1=new Label(String.valueOf(raf.readDouble()+"   "));
        pane3.add(lblIdAlcohol1,2,5,1,1);
        Label lblYearAlcohol1=new Label(String.valueOf(raf.readDouble()+"   "));
        pane3.add(lblYearAlcohol1,2,6,1,1);
        Label lblTypeAlcohol1=new Label(readString(raf, Record.SIZE_TYP, false));
        pane3.add(lblTypeAlcohol1,2,7,1,1);
             System.out.print("\n");
             ColumnConstraints c0=new ColumnConstraints();
             c0.setPercentWidth(20);
             ColumnConstraints c12=new ColumnConstraints();
             c12.setPercentWidth(40);
             pane3.getColumnConstraints().addAll(c0,c12);
            Scene scene3=new Scene(pane3);
            pane.setHgap(5);
            pane.setVgap(5);
            Insets inset=new Insets(5);
            pane3.setPadding(inset);
            Button btnBack=new Button("Go Back");
            pane3.add(btnBack,0,9,1,1);
            btnBack.setOnAction(new EventHandler<ActionEvent>(){
                public void handle(ActionEvent e){
                    stage3.close();
                }
            });
                        pane3.setPrefSize(600,230);
                        stage3.setTitle("Details about NF Screech");
                        stage3.setScene(scene3);
                        stage3.show();
                        //provide implementation here and do similar with all other 
                        //alcohols
                    }
                       catch(Exception f){
                   Alert alertError=new Alert(Alert.AlertType.ERROR);
                   alertError.setContentText(f.getMessage());
                   alertError.setHeaderText("Data cannot be entered in database");
                   alertError.show();
                        }
                }});//end btnAlcohol1 processing
     btnAlcohol2.setOnAction(new EventHandler<ActionEvent>(){
                    public void handle(ActionEvent e){
        Stage stage4=new Stage();
        GridPane pane4=new GridPane();
        try{
        RandomAccessFile raf=new RandomAccessFile("data/products.txt","rw");
        raf.seek(Record.SIZE_REC);
        Label lblInforTitle=new Label("Detailed Information: ");
         pane4.add(lblInforTitle,0,0,2,1);
        Label lblName=new Label("The alcohol Name is: ");
        pane4.add(lblName,1,1,1,1);
        Label lblQuantity=new Label("The alcohol Quantity is: ");
        pane4.add(lblQuantity,1,2,1,1);
        Label lblPrice=new Label("The alcohol Price is: ");
        pane4.add(lblPrice,1,3,1,1);
        Label lblLocation=new Label("The alcohol Location is: ");
        pane4.add(lblLocation,1,4,1,1);
        Label lblId=new Label("The alcohol ID is: ");
        pane4.add(lblId,1,5,1,1);
        Label lblYear=new Label("The alcohol Manufactured Year is: ");
        pane4.add(lblYear,1,6,1,1);
        Label lblType=new Label("The alcohol Container Type is: ");
        pane4.add(lblType,1,7,1,1);
        Label lblNameAlcohol2=new Label(readString(raf, Record.SIZE_NME, false));
        pane4.add(lblNameAlcohol2,2,1,1,1);
        Label lblQuantityAlcohol2=new Label(String.valueOf(raf.readDouble()));
        pane4.add(lblQuantityAlcohol2,2,2,1,1);
        Label lblPriceAlcohol2=new Label(String.valueOf(raf.readDouble()));
        pane4.add(lblPriceAlcohol2,2,3,1,1);
        Label lblLocationAlcohol2=new Label(readString(raf, Record.SIZE_LOCN, false));
        pane4.add(lblLocationAlcohol2,2,4,1,1);
        Label lblIdAlcohol2=new Label(String.valueOf(raf.readDouble()));
        pane4.add(lblIdAlcohol2,2,5,1,1);
        Label lblYearAlcohol2=new Label(String.valueOf(raf.readDouble()));
        pane4.add(lblYearAlcohol2,2,6,1,1);
        Label lblTypeAlcohol2=new Label(readString(raf, Record.SIZE_TYP, false));
        pane4.add(lblTypeAlcohol2,2,7,1,1);
             System.out.print("\n");
             ColumnConstraints c0=new ColumnConstraints();
             c0.setPercentWidth(20);
             ColumnConstraints c12=new ColumnConstraints();
             c12.setPercentWidth(40);
             pane4.getColumnConstraints().addAll(c0,c12);
            Scene scene4=new Scene(pane4);
            pane.setHgap(5);
            pane.setVgap(5);
            Insets inset=new Insets(5);
            pane4.setPadding(inset);
            Button btnBack=new Button("Go Back");
            pane4.add(btnBack,0,9,1,1);
            btnBack.setOnAction(new EventHandler<ActionEvent>(){
                public void handle(ActionEvent e){
                    stage4.close();
                }
            });
                        pane4.setPrefSize(600,230);
                        stage4.setTitle("Details about Bloody Ceaser");
                        stage4.setScene(scene4);
                        stage4.show();
                        //provide implementation here and do similar with all other 
                        //alcohols
                    }
                       catch(Exception f){
                        Alert alertError=new Alert(Alert.AlertType.ERROR);
                   alertError.setContentText(f.getMessage());
                   alertError.setHeaderText("Data cannot be entered in database");
                   alertError.show();
                        }
                }});//end btnAlcohol2 processing
     btnAlcohol3.setOnAction(new EventHandler<ActionEvent>(){
                    public void handle(ActionEvent e){
        Stage stage4=new Stage();
        GridPane pane4=new GridPane();
        try{
        RandomAccessFile raf=new RandomAccessFile("data/products.txt","rw");
        raf.seek(Record.SIZE_REC*2);
        Label lblInforTitle=new Label("Detailed Information: ");
         pane4.add(lblInforTitle,0,0,2,1);
        Label lblName=new Label("The alcohol Name is: ");
        pane4.add(lblName,1,1,1,1);
        Label lblQuantity=new Label("The alcohol Quantity is: ");
        pane4.add(lblQuantity,1,2,1,1);
        Label lblPrice=new Label("The alcohol Price is: ");
        pane4.add(lblPrice,1,3,1,1);
        Label lblLocation=new Label("The alcohol Location is: ");
        pane4.add(lblLocation,1,4,1,1);
        Label lblId=new Label("The alcohol ID is: ");
        pane4.add(lblId,1,5,1,1);
        Label lblYear=new Label("The alcohol Manufactured Year is: ");
        pane4.add(lblYear,1,6,1,1);
        Label lblType=new Label("The alcohol Container Type is: ");
        pane4.add(lblType,1,7,1,1);
        Label lblNameAlcohol3=new Label(readString(raf, Record.SIZE_NME, false));
        pane4.add(lblNameAlcohol3,2,1,1,1);
        Label lblQuantityAlcohol3=new Label(String.valueOf(raf.readDouble()));
        pane4.add(lblQuantityAlcohol3,2,2,1,1);
        Label lblPriceAlcohol3=new Label(String.valueOf(raf.readDouble()));
        pane4.add(lblPriceAlcohol3,2,3,1,1);
        Label lblLocationAlcohol3=new Label(readString(raf, Record.SIZE_LOCN, false));
        pane4.add(lblLocationAlcohol3,2,4,1,1);
        Label lblIdAlcohol3=new Label(String.valueOf(raf.readDouble()));
        pane4.add(lblIdAlcohol3,2,5,1,1);
        Label lblYearAlcohol3=new Label(String.valueOf(raf.readDouble()));
        pane4.add(lblYearAlcohol3,2,6,1,1);
        Label lblTypeAlcohol3=new Label(readString(raf, Record.SIZE_TYP, false));
        pane4.add(lblTypeAlcohol3,2,7,1,1);
             System.out.print("\n");
             ColumnConstraints c0=new ColumnConstraints();
             c0.setPercentWidth(20);
             ColumnConstraints c12=new ColumnConstraints();
             c12.setPercentWidth(40);
             pane4.getColumnConstraints().addAll(c0,c12);
            Scene scene4=new Scene(pane4);
            pane.setHgap(5);
            pane.setVgap(5);
            Insets inset=new Insets(5);
            pane4.setPadding(inset);
            Button btnBack=new Button("Go Back");
            pane4.add(btnBack,0,9,1,1);
            btnBack.setOnAction(new EventHandler<ActionEvent>(){
                public void handle(ActionEvent e){
                    stage4.close();
                }
            });
                        pane4.setPrefSize(600,230);
                        stage4.setTitle("Details about Molson Beer");
                        stage4.setScene(scene4);
                        stage4.show();
                        //provide implementation here and do similar with all other 
                        //alcohols
                    }
                       catch(Exception f){
                        Alert alertError=new Alert(Alert.AlertType.ERROR);
                   alertError.setContentText(f.getMessage());
                   alertError.setHeaderText("Data cannot be entered in database");
                   alertError.show();
                        }
                }});//end btnAlcohol3 processing
     btnAlcohol4.setOnAction(new EventHandler<ActionEvent>(){
                    public void handle(ActionEvent e){
        Stage stage4=new Stage();
        GridPane pane4=new GridPane();
        try{
        RandomAccessFile raf=new RandomAccessFile("data/products.txt","rw");
        raf.seek(Record.SIZE_REC*3);
        Label lblInforTitle=new Label("Detailed Information: ");
         pane4.add(lblInforTitle,0,0,2,1);
        Label lblName=new Label("The alcohol Name is: ");
        pane4.add(lblName,1,1,1,1);
        Label lblQuantity=new Label("The alcohol Quantity is: ");
        pane4.add(lblQuantity,1,2,1,1);
        Label lblPrice=new Label("The alcohol Price is: ");
        pane4.add(lblPrice,1,3,1,1);
        Label lblLocation=new Label("The alcohol Location is: ");
        pane4.add(lblLocation,1,4,1,1);
        Label lblId=new Label("The alcohol ID is: ");
        pane4.add(lblId,1,5,1,1);
        Label lblYear=new Label("The alcohol Manufactured Year is: ");
        pane4.add(lblYear,1,6,1,1);
        Label lblType=new Label("The alcohol Container Type is: ");
        pane4.add(lblType,1,7,1,1);
        Label lblNameAlcohol4=new Label(readString(raf, Record.SIZE_NME, false));
        pane4.add(lblNameAlcohol4,2,1,1,1);
        Label lblQuantityAlcohol4=new Label(String.valueOf(raf.readDouble()));
        pane4.add(lblQuantityAlcohol4,2,2,1,1);
        Label lblPriceAlcohol4=new Label(String.valueOf(raf.readDouble()));
        pane4.add(lblPriceAlcohol4,2,3,1,1);
        Label lblLocationAlcohol4=new Label(readString(raf, Record.SIZE_LOCN, false));
        pane4.add(lblLocationAlcohol4,2,4,1,1);
        Label lblIdAlcohol4=new Label(String.valueOf(raf.readDouble()));
        pane4.add(lblIdAlcohol4,2,5,1,1);
        Label lblYearAlcohol4=new Label(String.valueOf(raf.readDouble()));
        pane4.add(lblYearAlcohol4,2,6,1,1);
        Label lblTypeAlcohol4=new Label(readString(raf, Record.SIZE_TYP, false));
        pane4.add(lblTypeAlcohol4,2,7,1,1);
             System.out.print("\n");
             ColumnConstraints c0=new ColumnConstraints();
             c0.setPercentWidth(20);
             ColumnConstraints c12=new ColumnConstraints();
             c12.setPercentWidth(40);
             pane4.getColumnConstraints().addAll(c0,c12);
            Scene scene4=new Scene(pane4);
            pane.setHgap(5);
            pane.setVgap(5);
            Insets inset=new Insets(5);
            pane4.setPadding(inset);
            Button btnBack=new Button("Go Back");
            pane4.add(btnBack,0,9,1,1);
            btnBack.setOnAction(new EventHandler<ActionEvent>(){
                public void handle(ActionEvent e){
                    stage4.close();
                }
            });
                        pane4.setPrefSize(600,230);
                        stage4.setTitle("Details about Yukon Jack");
                        stage4.setScene(scene4);
                        stage4.show();
                        //provide implementation here and do similar with all other 
                        //alcohols
                    }
                       catch(Exception f){
                        Alert alertError=new Alert(Alert.AlertType.ERROR);
                   alertError.setContentText(f.getMessage());
                   alertError.setHeaderText("Data cannot be entered in database");
                   alertError.show();
                        }
                }});//end btnAlcohol4 processing
     btnAlcohol5.setOnAction(new EventHandler<ActionEvent>(){
                    public void handle(ActionEvent e){
        Stage stage4=new Stage();
        GridPane pane4=new GridPane();
        try{
        RandomAccessFile raf=new RandomAccessFile("data/products.txt","rw");
        raf.seek(Record.SIZE_REC*4);
        Label lblInforTitle=new Label("Detailed Information: ");
         pane4.add(lblInforTitle,0,0,2,1);
        Label lblName=new Label("The alcohol Name is: ");
        pane4.add(lblName,1,1,1,1);
        Label lblQuantity=new Label("The alcohol Quantity is: ");
        pane4.add(lblQuantity,1,2,1,1);
        Label lblPrice=new Label("The alcohol Price is: ");
        pane4.add(lblPrice,1,3,1,1);
        Label lblLocation=new Label("The alcohol Location is: ");
        pane4.add(lblLocation,1,4,1,1);
        Label lblId=new Label("The alcohol ID is: ");
        pane4.add(lblId,1,5,1,1);
        Label lblYear=new Label("The alcohol Manufactured Year is: ");
        pane4.add(lblYear,1,6,1,1);
        Label lblType=new Label("The alcohol Container Type is: ");
        pane4.add(lblType,1,7,1,1);
        Label lblNameAlcohol5=new Label(readString(raf, Record.SIZE_NME, false));
        pane4.add(lblNameAlcohol5,2,1,1,1);
        Label lblQuantityAlcohol5=new Label(String.valueOf(raf.readDouble()));
        pane4.add(lblQuantityAlcohol5,2,2,1,1);
        Label lblPriceAlcohol5=new Label(String.valueOf(raf.readDouble()));
        pane4.add(lblPriceAlcohol5,2,3,1,1);
        Label lblLocationAlcohol5=new Label(readString(raf, Record.SIZE_LOCN, false));
        pane4.add(lblLocationAlcohol5,2,4,1,1);
        Label lblIdAlcohol5=new Label(String.valueOf(raf.readDouble()));
        pane4.add(lblIdAlcohol5,2,5,1,1);
        Label lblYearAlcohol5=new Label(String.valueOf(raf.readDouble()));
        pane4.add(lblYearAlcohol5,2,6,1,1);
        Label lblTypeAlcohol5=new Label(readString(raf, Record.SIZE_TYP, false));
        pane4.add(lblTypeAlcohol5,2,7,1,1);
             System.out.print("\n");
             ColumnConstraints c0=new ColumnConstraints();
             c0.setPercentWidth(20);
             ColumnConstraints c12=new ColumnConstraints();
             c12.setPercentWidth(40);
             pane4.getColumnConstraints().addAll(c0,c12);
            Scene scene4=new Scene(pane4);
            pane.setHgap(5);
            pane.setVgap(5);
            Insets inset=new Insets(5);
            pane4.setPadding(inset);
            Button btnBack=new Button("Go Back");
            pane4.add(btnBack,0,9,1,1);
            btnBack.setOnAction(new EventHandler<ActionEvent>(){
                public void handle(ActionEvent e){
                    stage4.close();
                }
            });
                        pane4.setPrefSize(600,230);
                        stage4.setTitle("Details about Rev");
                        stage4.setScene(scene4);
                        stage4.show();
                        //provide implementation here and do similar with all other 
                        //alcohols
                    }
                       catch(Exception f){
                        Alert alertError=new Alert(Alert.AlertType.ERROR);
                   alertError.setContentText(f.getMessage());
                   alertError.setHeaderText("Data cannot be entered in database");
                   alertError.show();
                        }
                }});//end btnAlcohol5 processing
     btnAlcohol6.setOnAction(new EventHandler<ActionEvent>(){
                    public void handle(ActionEvent e){
        Stage stage4=new Stage();
        GridPane pane4=new GridPane();
        try{
        RandomAccessFile raf=new RandomAccessFile("data/products.txt","rw");
        raf.seek(Record.SIZE_REC*5);
        Label lblInforTitle=new Label("Detailed Information: ");
         pane4.add(lblInforTitle,0,0,2,1);
        Label lblName=new Label("The alcohol Name is: ");
        pane4.add(lblName,1,1,1,1);
        Label lblQuantity=new Label("The alcohol Quantity is: ");
        pane4.add(lblQuantity,1,2,1,1);
        Label lblPrice=new Label("The alcohol Price is: ");
        pane4.add(lblPrice,1,3,1,1);
        Label lblLocation=new Label("The alcohol Location is: ");
        pane4.add(lblLocation,1,4,1,1);
        Label lblId=new Label("The alcohol ID is: ");
        pane4.add(lblId,1,5,1,1);
        Label lblYear=new Label("The alcohol Manufactured Year is: ");
        pane4.add(lblYear,1,6,1,1);
        Label lblType=new Label("The alcohol Container Type is: ");
        pane4.add(lblType,1,7,1,1);
        Label lblNameAlcohol6=new Label(readString(raf, Record.SIZE_NME, false));
        pane4.add(lblNameAlcohol6,2,1,1,1);
        Label lblQuantityAlcohol6=new Label(String.valueOf(raf.readDouble()));
        pane4.add(lblQuantityAlcohol6,2,2,1,1);
        Label lblPriceAlcohol6=new Label(String.valueOf(raf.readDouble()));
        pane4.add(lblPriceAlcohol6,2,3,1,1);
        Label lblLocationAlcohol6=new Label(readString(raf, Record.SIZE_LOCN, false));
        pane4.add(lblLocationAlcohol6,2,4,1,1);
        Label lblIdAlcohol6=new Label(String.valueOf(raf.readDouble()));
        pane4.add(lblIdAlcohol6,2,5,1,1);
        Label lblYearAlcohol6=new Label(String.valueOf(raf.readDouble()));
        pane4.add(lblYearAlcohol6,2,6,1,1);
        Label lblTypeAlcohol6=new Label(readString(raf, Record.SIZE_TYP, false));
        pane4.add(lblTypeAlcohol6,2,7,1,1);
             System.out.print("\n");
             ColumnConstraints c0=new ColumnConstraints();
             c0.setPercentWidth(20);
             ColumnConstraints c12=new ColumnConstraints();
             c12.setPercentWidth(40);
             pane4.getColumnConstraints().addAll(c0,c12);
            Scene scene4=new Scene(pane4);
            pane.setHgap(5);
            pane.setVgap(5);
            Insets inset=new Insets(5);
            pane4.setPadding(inset);
            Button btnBack=new Button("Go Back");
            pane4.add(btnBack,0,9,1,1);
            btnBack.setOnAction(new EventHandler<ActionEvent>(){
                public void handle(ActionEvent e){
                    stage4.close();
                }
            });
                        pane4.setPrefSize(600,230);
                        stage4.setTitle("Details about Ice Wine");
                        stage4.setScene(scene4);
                        stage4.show();
                        //provide implementation here and do similar with all other 
                        //alcohols
                    }
                       catch(Exception f){
                        Alert alertError=new Alert(Alert.AlertType.ERROR);
                   alertError.setContentText(f.getMessage());
                   alertError.setHeaderText("Data cannot be entered in database");
                   alertError.show();
                        }
                }});//end btnAlcohol6 processing
     btnAlcohol7.setOnAction(new EventHandler<ActionEvent>(){
                    public void handle(ActionEvent e){
        Stage stage4=new Stage();
        GridPane pane4=new GridPane();
        try{
        RandomAccessFile raf=new RandomAccessFile("data/products.txt","rw");
        raf.seek(Record.SIZE_REC*6);
        Label lblInforTitle=new Label("Detailed Information: ");
         pane4.add(lblInforTitle,0,0,2,1);
        Label lblName=new Label("The alcohol Name is: ");
        pane4.add(lblName,1,1,1,1);
        Label lblQuantity=new Label("The alcohol Quantity is: ");
        pane4.add(lblQuantity,1,2,1,1);
        Label lblPrice=new Label("The alcohol Price is: ");
        pane4.add(lblPrice,1,3,1,1);
        Label lblLocation=new Label("The alcohol Location is: ");
        pane4.add(lblLocation,1,4,1,1);
        Label lblId=new Label("The alcohol ID is: ");
        pane4.add(lblId,1,5,1,1);
        Label lblYear=new Label("The alcohol Manufactured Year is: ");
        pane4.add(lblYear,1,6,1,1);
        Label lblType=new Label("The alcohol Container Type is: ");
        pane4.add(lblType,1,7,1,1);
        Label lblNameAlcohol7=new Label(readString(raf, Record.SIZE_NME, false));
        pane4.add(lblNameAlcohol7,2,1,1,1);
        Label lblQuantityAlcohol7=new Label(String.valueOf(raf.readDouble()));
        pane4.add(lblQuantityAlcohol7,2,2,1,1);
        Label lblPriceAlcohol7=new Label(String.valueOf(raf.readDouble()));
        pane4.add(lblPriceAlcohol7,2,3,1,1);
        Label lblLocationAlcohol7=new Label(readString(raf, Record.SIZE_LOCN, false));
        pane4.add(lblLocationAlcohol7,2,4,1,1);
        Label lblIdAlcohol7=new Label(String.valueOf(raf.readDouble()));
        pane4.add(lblIdAlcohol7,2,5,1,1);
        Label lblYearAlcohol7=new Label(String.valueOf(raf.readDouble()));
        pane4.add(lblYearAlcohol7,2,6,1,1);
        Label lblTypeAlcohol7=new Label(readString(raf, Record.SIZE_TYP, false));
        pane4.add(lblTypeAlcohol7,2,7,1,1);
             System.out.print("\n");
             ColumnConstraints c0=new ColumnConstraints();
             c0.setPercentWidth(20);
             ColumnConstraints c12=new ColumnConstraints();
             c12.setPercentWidth(40);
             pane4.getColumnConstraints().addAll(c0,c12);
            Scene scene4=new Scene(pane4);
            pane.setHgap(5);
            pane.setVgap(5);
            Insets inset=new Insets(5);
            pane4.setPadding(inset);
            Button btnBack=new Button("Go Back");
            pane4.add(btnBack,0,9,1,1);
            btnBack.setOnAction(new EventHandler<ActionEvent>(){
                public void handle(ActionEvent e){
                    stage4.close();
                }
            });
                        pane4.setPrefSize(600,230);
                        stage4.setTitle("Details about Raymond Messey");
                        stage4.setScene(scene4);
                        stage4.show();
                        //provide implementation here and do similar with all other 
                        //alcohols
                    }
                       catch(Exception f){
                        Alert alertError=new Alert(Alert.AlertType.ERROR);
                   alertError.setContentText(f.getMessage());
                   alertError.setHeaderText("Data cannot be entered in database");
                   alertError.show();
                        }
                }});//end btnAlcohol7 processing
     btnAlcohol8.setOnAction(new EventHandler<ActionEvent>(){
                    public void handle(ActionEvent e){
        Stage stage4=new Stage();
        GridPane pane4=new GridPane();
        try{
        RandomAccessFile raf=new RandomAccessFile("data/products.txt","rw");
        raf.seek(Record.SIZE_REC*7);
        Label lblInforTitle=new Label("Detailed Information: ");
         pane4.add(lblInforTitle,0,0,2,1);
        Label lblName=new Label("The alcohol Name is: ");
        pane4.add(lblName,1,1,1,1);
        Label lblQuantity=new Label("The alcohol Quantity is: ");
        pane4.add(lblQuantity,1,2,1,1);
        Label lblPrice=new Label("The alcohol Price is: ");
        pane4.add(lblPrice,1,3,1,1);
        Label lblLocation=new Label("The alcohol Location is: ");
        pane4.add(lblLocation,1,4,1,1);
        Label lblId=new Label("The alcohol ID is: ");
        pane4.add(lblId,1,5,1,1);
        Label lblYear=new Label("The alcohol Manufactured Year is: ");
        pane4.add(lblYear,1,6,1,1);
        Label lblType=new Label("The alcohol Container Type is: ");
        pane4.add(lblType,1,7,1,1);
        Label lblNameAlcohol8=new Label(readString(raf, Record.SIZE_NME, false));
        pane4.add(lblNameAlcohol8,2,1,1,1);
        Label lblQuantityAlcohol8=new Label(String.valueOf(raf.readDouble()));
        pane4.add(lblQuantityAlcohol8,2,2,1,1);
        Label lblPriceAlcohol8=new Label(String.valueOf(raf.readDouble()));
        pane4.add(lblPriceAlcohol8,2,3,1,1);
        Label lblLocationAlcohol8=new Label(readString(raf, Record.SIZE_LOCN, false));
        pane4.add(lblLocationAlcohol8,2,4,1,1);
        Label lblIdAlcohol8=new Label(String.valueOf(raf.readDouble()));
        pane4.add(lblIdAlcohol8,2,5,1,1);
        Label lblYearAlcohol8=new Label(String.valueOf(raf.readDouble()));
        pane4.add(lblYearAlcohol8,2,6,1,1);
        Label lblTypeAlcohol8=new Label(readString(raf, Record.SIZE_TYP, false));
        pane4.add(lblTypeAlcohol8,2,7,1,1);
             System.out.print("\n");
             ColumnConstraints c0=new ColumnConstraints();
             c0.setPercentWidth(20);
             ColumnConstraints c12=new ColumnConstraints();
             c12.setPercentWidth(40);
             pane4.getColumnConstraints().addAll(c0,c12);
            Scene scene4=new Scene(pane4);
            pane.setHgap(5);
            pane.setVgap(5);
            Insets inset=new Insets(5);
            pane4.setPadding(inset);
            Button btnBack=new Button("Go Back");
            pane4.add(btnBack,0,9,1,1);
            btnBack.setOnAction(new EventHandler<ActionEvent>(){
                public void handle(ActionEvent e){
                    stage4.close();
                }
            });
                        pane4.setPrefSize(600,230);
                        stage4.setTitle("Details about Jameson");
                        stage4.setScene(scene4);
                        stage4.show();
                        //provide implementation here and do similar with all other 
                        //alcohols
                    }
                       catch(Exception f){
                       Alert alertError=new Alert(Alert.AlertType.ERROR);
                   alertError.setContentText(f.getMessage());
                   alertError.setHeaderText("Data cannot be entered in database");
                   alertError.show();
                        }
                }});//end btnAlcohol8 processing
     btnAlcohol9.setOnAction(new EventHandler<ActionEvent>(){
                    public void handle(ActionEvent e){
        Stage stage4=new Stage();
        GridPane pane4=new GridPane();
        try{
        RandomAccessFile raf=new RandomAccessFile("data/products.txt","rw");
        raf.seek(Record.SIZE_REC*8);
        Label lblInforTitle=new Label("Detailed Information: ");
         pane4.add(lblInforTitle,0,0,2,1);
        Label lblName=new Label("The alcohol Name is: ");
        pane4.add(lblName,1,1,1,1);
        Label lblQuantity=new Label("The alcohol Quantity is: ");
        pane4.add(lblQuantity,1,2,1,1);
        Label lblPrice=new Label("The alcohol Price is: ");
        pane4.add(lblPrice,1,3,1,1);
        Label lblLocation=new Label("The alcohol Location is: ");
        pane4.add(lblLocation,1,4,1,1);
        Label lblId=new Label("The alcohol ID is: ");
        pane4.add(lblId,1,5,1,1);
        Label lblYear=new Label("The alcohol Manufactured Year is: ");
        pane4.add(lblYear,1,6,1,1);
        Label lblType=new Label("The alcohol Container Type is: ");
        pane4.add(lblType,1,7,1,1);
        Label lblNameAlcohol9=new Label(readString(raf, Record.SIZE_NME, false));
        pane4.add(lblNameAlcohol9,2,1,1,1);
        Label lblQuantityAlcohol9=new Label(String.valueOf(raf.readDouble()));
        pane4.add(lblQuantityAlcohol9,2,2,1,1);
        Label lblPriceAlcohol9=new Label(String.valueOf(raf.readDouble()));
        pane4.add(lblPriceAlcohol9,2,3,1,1);
        Label lblLocationAlcohol9=new Label(readString(raf, Record.SIZE_LOCN, false));
        pane4.add(lblLocationAlcohol9,2,4,1,1);
        Label lblIdAlcohol9=new Label(String.valueOf(raf.readDouble()));
        pane4.add(lblIdAlcohol9,2,5,1,1);
        Label lblYearAlcohol9=new Label(String.valueOf(raf.readDouble()));
        pane4.add(lblYearAlcohol9,2,6,1,1);
        Label lblTypeAlcohol9=new Label(readString(raf, Record.SIZE_TYP, false));
        pane4.add(lblTypeAlcohol9,2,7,1,1);
             System.out.print("\n");
             ColumnConstraints c0=new ColumnConstraints();
             c0.setPercentWidth(20);
             ColumnConstraints c12=new ColumnConstraints();
             c12.setPercentWidth(40);
             pane4.getColumnConstraints().addAll(c0,c12);
            Scene scene4=new Scene(pane4);
            pane.setHgap(5);
            pane.setVgap(5);
            Insets inset=new Insets(5);
            pane4.setPadding(inset);
            Button btnBack=new Button("Go Back");
            pane4.add(btnBack,0,9,1,1);
            btnBack.setOnAction(new EventHandler<ActionEvent>(){
                public void handle(ActionEvent e){
                    stage4.close();
                }
            });
                        pane4.setPrefSize(600,230);
                        stage4.setTitle("Details about Crown Royal");
                        stage4.setScene(scene4);
                        stage4.show();
                        //provide implementation here and do similar with all other 
                        //alcohols
                    }
                       catch(Exception f){
                        Alert alertError=new Alert(Alert.AlertType.ERROR);
                   alertError.setContentText(f.getMessage());
                   alertError.setHeaderText("Data cannot be entered in database");
                   alertError.show();
                        }
                }});//end btnAlcohol9 processing

                Button btnDeleteProduct=new Button("Delete Product");
                pane1.add(btnDeleteProduct,4,8,1,1);
                 GridPane.setHalignment(btnDeleteProduct,HPos.RIGHT);
                btnDeleteProduct.setOnAction(new EventHandler<ActionEvent>(){
                   public void handle(ActionEvent e){
                       //provide implementation of Delete product
                       try{
                       RandomAccessFile raf=new RandomAccessFile("data/products.txt","rw");
//        Alert inputDialogDelete=new Alert(Alert.AlertType.CONFIRMATION);
//        inputDialogDelete.setContentText("Enter the ID of the liquor you want to delete : ");
//        inputDialogDelete.setHeaderText("Warning ! You are about to DELETE something");
//        inputDialogDelete.show();
                       Stage stage4=new Stage();
                       GridPane pane4=new GridPane();
                       Label lblaaa=new Label("Enter product ID to delete a liquor :");
                       TextField inputDialogDelete=new TextField();
                       pane4.add(lblaaa,0,0,1,1);
                       pane4.add(inputDialogDelete,1,0,1,1);
                       inputDialogDelete.setOnAction(new EventHandler<ActionEvent>(){
                           public void handle(ActionEvent e){
                               try{
                               if((Integer.parseInt(inputDialogDelete.getText()))<10 && 
                (Integer.parseInt(inputDialogDelete.getText()))>0){
                                   
            raf.seek(Record.SIZE_REC*((Integer.parseInt(inputDialogDelete.getText()))-1));
          //  raf.setLength(file.);
           // Record rcd=new Record();//no argumnent defautlt object
            raf.writeUTF("");
            raf.writeDouble(0);
            raf.writeDouble(0);
            raf.writeUTF("");
            raf.writeUTF("");
            raf.writeInt(0);
            raf.writeUTF("");
            inputDialogDelete.setText(" ");
             Alert alertThanks=new Alert(Alert.AlertType.CONFIRMATION);
                   alertThanks.setContentText("Your product has been deleted");
                   //alertThanks.setHeaderText("");
                   alertThanks.show();}
        
        else{
          //  System.out.println("Product ID does not exist !!");
             Alert alertError=new Alert(Alert.AlertType.ERROR);
                   alertError.setContentText("Product ID does not exist !!");
                   alertError.show();
        }}
        catch(Exception b){
                Alert alertError=new Alert(Alert.AlertType.ERROR);
                   alertError.setContentText("Product ID does not exist !!");
                   alertError.show();
                }
                           }
                       });
                       pane4.setHgap(5);
            pane4.setVgap(5);
            Insets inset=new Insets(5);
            pane4.setPadding(inset);
            pane4.setPrefSize(400,80);
                       Scene scene4=new Scene(pane4);
                       stage4.setScene(scene4);
                       stage4.show();
                       
        }
        catch(Exception w){
                    System.out.println(w.getMessage());}
                    
                       
                   }} );//end btnDelete processing
                
                
                   
                
                Insets inset=new Insets(5);
                pane1.setPadding(inset);

                txtRateUs.setOnAction(new EventHandler<ActionEvent>(){
                   public void handle(ActionEvent e){
                       if(Integer.parseInt(txtRateUs.getText())>=0 && 
                               Integer.parseInt(txtRateUs.getText())<=5){
                    Alert alert1=new Alert(Alert.AlertType.INFORMATION);
                    alert1.setHeaderText("You Rated Us");
                    alert1.setContentText("Thanks for your precious feedback");
                    alert1.show();
                    txtRateUs.setText("");
                   } 
                   else{
                     Alert alert2=new Alert(Alert.AlertType.INFORMATION);
                    alert2.setHeaderText("Invalid input");
                    alert2.setContentText("Please Rate us out of 5. Thanks");
                    alert2.show();
                }
                }});//end txtRateUs processing


                Button btnAddProduct=new Button("Add a new Product");
                pane1.add(btnAddProduct,4,6,1,1);
                GridPane.setHalignment(btnAddProduct,HPos.RIGHT);
                btnAddProduct.setOnAction(new EventHandler<ActionEvent>(){
                    public void handle(ActionEvent e){
                        Stage stage2=new Stage();
                        GridPane pane2=new GridPane();
                        Label lblInputTitle=new Label("Enter following details to add product "
                                + "to database:");
                        lblInputTitle.setStyle("-fx-font:13pt verdana");
                        pane2.add(lblInputTitle,0,0,4,1);
                        Label lblInputLiquorName=new Label("Liquor Name:");
                        TextField txtInputLiquorName=new TextField();
                        pane2.add(lblInputLiquorName,1,1,2,1);
                        pane2.add(txtInputLiquorName,2,1,1,1);
                        Label lblInputLiquorId=new Label("Product ID:");
                        TextField txtInputLiquorId=new TextField();
                        pane2.add(lblInputLiquorId,1,2,2,1);
                        pane2.add(txtInputLiquorId,2,2,1,1);
                        Label lblInputQuantity=new Label("Quantity:");
                        TextField txtInputQuantity=new TextField();
                        pane2.add(lblInputQuantity,1,3,2,1);
                        pane2.add(txtInputQuantity,2,3,1,1);
                        Label lblInputManufacturedYear=new Label("Manufactured Year:");
                        TextField txtInputManufacturedYear=new TextField();
                        pane2.add(lblInputManufacturedYear,1,4,2,1);
                        pane2.add(txtInputManufacturedYear,2,4,1,1);
                        Label lblInputLocation=new Label("Location:");
                        TextField txtInputLocation=new TextField();
                        pane2.add(lblInputLocation,1,5,2,1);
                        pane2.add(txtInputLocation,2,5,1,1);
                        Label lblInputTypeOfContainer=new Label("Type Of Container:");
                        TextField txtInputTypeOfContainer=new TextField();
                        pane2.add(lblInputTypeOfContainer,1,6,2,1);
                        pane2.add(txtInputTypeOfContainer,2,6,1,1);
                        Label lblInputPrice=new Label("Price:");
                        TextField txtInputPrice=new TextField();
                        pane2.add(lblInputPrice,1,7,2,1);
                        pane2.add(txtInputPrice,2,7,1,1);
                        Button btnInputDone=new Button("Done");
                        Button btnInputBack=new Button("Back to previous window");
                        pane2.add(btnInputDone,1,8,1,1);
                        pane2.add(btnInputBack,2,8,1,1);
                        try {
                        RandomAccessFile raf=new RandomAccessFile("data/products.txt","rw");
                       txtInputLiquorName.getText();
                        }
                        catch(Exception z){
                            System.out.println(z.getMessage());
                        }
                Insets inset=new Insets(5);
                pane2.setPadding(inset);
                        btnInputBack.setOnAction(new EventHandler<ActionEvent>(){
                            public void handle(ActionEvent e){
                                stage2.close();
                            }
                        });//end btnInputBack to stage1
                        btnInputDone.setOnAction(new EventHandler<ActionEvent>(){
                            public void handle(ActionEvent e){

                                try {
                             //       File file=new File("data/products.txt");
                        RandomAccessFile raf=new RandomAccessFile("data/products.txt","rw");
                        double length=raf.length();
                               raf.seek(raf.length());
                                PrintWriter pw=new PrintWriter(new BufferedWriter
                                (new FileWriter("data/products.txt",true)));
                                Record rcdObject=new Record(txtInputLiquorName.getText(),
                                        Double.parseDouble(txtInputQuantity.getText()),
                                Double.parseDouble(txtInputPrice.getText()),
                                        txtInputLocation.getText(),
                                txtInputLiquorId.getText(),
                                        Integer.parseInt(txtInputManufacturedYear.getText()),
                                txtInputTypeOfContainer.getText());
                                pw.print(rcdObject);
                                pw.close();
                                txtInputLiquorName.setText("");
                                txtInputLiquorId.setText("");
                                txtInputQuantity.setText("");
                                txtInputLocation.setText("");
                                txtInputPrice.setText("");
                                txtInputManufacturedYear.setText("");
                                txtInputTypeOfContainer.setText("");
                                if(raf.getFilePointer()>=length){//put an if condition where error is coming
                                Alert alertAdded=new Alert(Alert.AlertType.INFORMATION);
                                alertAdded.setContentText("Your product has been added to your database."
                                        + " Thanks for your precious time");
                                alertAdded.show();}
                                }//end try block
                                catch(Exception k){
                                    Alert alertAdded=new Alert(Alert.AlertType.INFORMATION);
                                alertAdded.setContentText("The product is not added.");   
                                alertAdded.show();
                                }
                                //give implementtaion here to be given
                                //implementtaion of saving it to the database
                            }
                        });//end btnInputBack to stage1
                        ColumnConstraints c01=new ColumnConstraints();
                ColumnConstraints c2=new ColumnConstraints();
               // ColumnConstraints c4=new ColumnConstraints();
                c01.setPercentWidth(15);
                c2.setPercentWidth(30);
                //c4.setPercentWidth(40);
                pane2.getColumnConstraints().addAll(c01,c2);
                pane2.setHgap(5);
                pane2.setVgap(5);
                stage2.setTitle("Add new Product");
                        pane2.setPrefSize(500,200);
                        Scene scene2=new Scene(pane2);
                        stage2.setScene(scene2);
                    stage2.show();
                    }

                });//end btnAddNewProduct processing
               // DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
               // Date date = new Date();
               // pane1.add(,4,4,1,1);
                Label lblAllRightsReserved=new Label("           All Rights Reserved");
                lblAllRightsReserved.setStyle("-fx-font:12pt calibri; -fx-font-weight:bold;");
                pane1.add(lblAllRightsReserved,2,10,2,1);
              //  pane1.setGridLinesVisible(true);
            }
            else{
                txtUsername.setText("");
                txtPassword.setText("");
                Alert alert=new Alert(Alert.AlertType.ERROR);
                alert.setContentText("Invalid credentials. Cannot process further.");
                alert.setHeaderText("Error");
                alert.show();
                 }//end else
           }//end handle method

        });//end btnlogin
        }//end start method






        /**
         * @param args the command line arguments
         */
        public static void main(String[] args) {
            launch(args);
        }

    }
