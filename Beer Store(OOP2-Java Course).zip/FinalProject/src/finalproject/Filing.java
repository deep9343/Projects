package finalproject;
import finalproject.Record;
import finalproject.RecordList;
import java.io.File;
import java.io.IOException;
import java.io.RandomAccessFile;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author ashuc
 */
public class Filing {
    public static void main(String args[]) throws Exception{
        File file=new File("data/products.txt");
        final int NUM_OF_REC=9;
        String[] liquorNames={"Newfoundland Screech", "Bloody Caesar", "Molson beer", 
            "Yukon Jack", "Rev", "Icewine", "Raymond Messey", "Jameson", "Crown Royal"};
        double[] quantity={250, 750, 100, 150, 225, 250, 500, 750, 100};
        double[] price={20.5, 30, 40.5, 50, 60, 70, 80, 90.5, 25.5};
        String[] locationId={"1","2","3","4","5","6","7","8","9"};
        String[] location={"A100/1","A100/2","A100/3","A200/4","A200/5","A200/6"
        ,"A300/7","A300/8","A300/9"};
        int[] manufacturedYear={1900,1941,1920,1900,1941,1920,1900,1941,1921,};
        String[] typeOfLiquorContainer={"Bottle", "Canister","Bottle", "Canister",
            "Bottle", "Canister","Bottle", "Canister","Bottle"};
        RecordList list=new RecordList();
            for(int i=0;i<NUM_OF_REC;i++){
                list.add(new Record(liquorNames[i],quantity[i],price[i],location[i],
                locationId[i],manufacturedYear[i],typeOfLiquorContainer[i]));
            }
            for(Record e: list){
                System.out.println(e);
            }
            try{
                RandomAccessFile raf=new RandomAccessFile(file,"rw");
                raf.setLength(0);
                raf.seek(0);
                for(int i=1;i<=NUM_OF_REC;i++){
                  raf.writeChars(prepStringField(list.get(i).getLiquorName(),25));//doesnt need preparing string
                //becaise its already been done in the constructtor
                  raf.writeDouble(list.get(i).getQuantity());
                   raf.writeDouble(list.get(i).getPrice());
                   raf.writeChars(list.get(i).getLocation());
                  raf.writeChars(list.get(i).getLiquorId());
                  raf.writeInt(list.get(i).getManufacturedYear());
                   raf.writeChars(list.get(i).getTypeOfLiquorContainer());
                  }
                raf.seek(0);//setting file pointer again to 0
                //reading to file till end
                 while (raf.getFilePointer() != raf.length()) // reading the file to the end 
            {
                
                System.out.print(readString(raf, Record.SIZE_NME, false));
                System.out.print(raf.readDouble() + "   ");
                System.out.print(raf.readDouble()+ "   ");
                System.out.print(readString(raf, Record.SIZE_LOCN, false));
                System.out.print(readString(raf, Record.SIZE_ID, false));
                System.out.print(raf.readInt()+ "   ");
                System.out.print(readString(raf, Record.SIZE_TYP, false));
                System.out.print("\n");
            }
            }
            catch(Exception e){
                System.out.println(e.getMessage());
            }
            
            
    }//end main method
    
    public static String prepStringField(String value, int size) {
        if (value.length() > size) {
            return value.substring(0, size);
        }
        while (value.length() != size) {
            value += " ";
        }
        return value;
    }
    public static String readString(RandomAccessFile raf, int size, boolean trim)
            throws IOException {
        String n = "";
        for (int i = 0; i < size; i++) {
            n += String.valueOf(raf.readChar());
        }
        return (trim) ? n.trim() : n; // return trimmed if required
    }
    
}//end class Filing
