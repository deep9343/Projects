/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package finalproject;

import java.io.IOException;
import java.io.RandomAccessFile;

/**
 *
 * @author ashuc
 */
public class Record {
    private String liquorName;
    private double quantity;
    private double price;
    private String location;
    private String liquorId;
    private int manufacturedYear;
    private String typeOfLiquorContainer;
    public static final int SIZE_NME=25;
    public static final int SIZE_QTY=20;
   // public static final int SIZE_PRI=20;
    public static final int SIZE_LOCN=20;
    public static final int SIZE_ID=15;
    //public static final int SIZE_YR=20;
    public static final int SIZE_TYP=20;
    public static final int SIZE_REC=2*(SIZE_NME+SIZE_LOCN+SIZE_TYP)+2*8+2*4;
    //8 byte for double and 4 byte for int 
    public Record(String liquorName, double quantity,double price,String location,
            String liquorId, int manufacturedYear,String typeOfLiquorContainer){
        this.liquorName=prepStringField(liquorName,SIZE_NME);
        this.liquorId=prepStringField(liquorId,SIZE_ID);
        if(quantity >0 && price >0){
        this.quantity=quantity;
        this.price=price;
        }
        else{
            System.out.println("Quantity and Price can never be negative.");
        }
        this.location=prepStringField(location,SIZE_LOCN);
        if(manufacturedYear > 1800 && manufacturedYear < 2018){
        this.manufacturedYear=manufacturedYear;
        }
        else{
            System.out.println("We don't have liquor that is manufactured before 1800 "
                    + "and after 2018");
        }
        this.typeOfLiquorContainer=prepStringField(typeOfLiquorContainer,SIZE_TYP);
    }
    public Record(){
        this.liquorName="TBD";
        this.quantity=0.0;
        this.price=0.0;
        this.location="TBD";
        this.liquorId="X0X0X0";
        this.manufacturedYear=0000;
        this.typeOfLiquorContainer="TBD";
    }
    public String getLiquorName(){
        return this.liquorName;
    }
     public double getQuantity(){
        return this.quantity;
    }
      public double getPrice(){
        return this.price;
    }
       public String getLocation(){
        return this.location;
    }
        public String getLiquorId(){
        return this.liquorId;
    }
         public int getManufacturedYear(){
        return this.manufacturedYear;
    }
          public String getTypeOfLiquorContainer(){
        return this.typeOfLiquorContainer;
    }
    public void setLiquorName(String liquorName){
        this.liquorName=liquorName;
    }
    public void setQuantity(double quantity){
        this.quantity=quantity;
    }
    public void setPrice(double price){
        this.price=price;
    }
    public void setLocation(String location){
        this.location=location;
    }
    public void setLiquorId(String liquorId){
        this.liquorId=liquorId;
    }
    public void setManufacturedYear(int manufacturedYear){
        this.manufacturedYear=manufacturedYear;
    }
    public void setTypeOfLiquorContainer(String type){
        this.typeOfLiquorContainer=type;
    }
    public String toString(){
        String str="";
        System.out.println("The alcohol name is: "+this.getLiquorName());
        System.out.println("The alcohol quantity is: "+this.getQuantity()+ " ml");
        System.out.println("The alcohol ID is: #"+this.getLiquorId());
        System.out.println("The alcohol price is: "+this.getPrice() + " CAD");
        System.out.println("The alcohol location is: "+this.getLocation());
        System.out.println("The alcohol manufactured year is: "+this.getManufacturedYear());
        System.out.println("The alcohol container type is: "+this.getTypeOfLiquorContainer());
        return str;
    }
    public String prepStringField(String value, int size) {
        if (value.length() > size) {
            return value.substring(0, size);
        }
        while (value.length() != size) {
            value += " ";
        }
        return value;
    }
    
     public String readString(RandomAccessFile raf, int size, boolean trim)
            throws IOException {
        String n = "";
        for (int i = 0; i < size; i++) {
            n += String.valueOf(raf.readChar());
        }
        return (trim) ? n.trim() : n; // return trimmed if required
    }
    
}
