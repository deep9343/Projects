Beer Store(OOP2-Java Course)
January 2018 � April 2018

�Created application using Java, JavaFX, Database.
�I made it with Filling.GUI and RecordList.
�An elementary POS program created for 2nd Sem java Final Project of Sheridan College
�It is basic POS system of Beer Store Like LCBO which has all functionality like add product. search product,calculate the final bill payment etc.

