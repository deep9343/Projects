﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;

namespace Project
{
    public partial class WebForm5 : System.Web.UI.Page
    {
        private int numberOfRows=0;
        private int total_quantity=0;
        private double total_price=0;
        private double total_price_tax = 0;
        private double final_price = 0;

        protected void Page_Load(object sender, EventArgs e)
        {
            numberOfRows = GridView1.Rows.Count;

            for (int i = 0; i < numberOfRows; i++) {
                //total_quantity += Int32.Parse(GridView1.Rows[i].Cells[3].Text);
                if (Int32.TryParse(GridView1.Rows[i].Cells[3].Text, out int quantity)) {
                    total_quantity += quantity;
                }
                //total_price += Double.Parse(GridView1.Rows[i].Cells[5].Text)* Int32.Parse(GridView1.Rows[i].Cells[3].Text);
                if (Double.TryParse(GridView1.Rows[i].Cells[5].Text, out double price)) {
                    total_price += price * quantity;
                }
            }

            totalQuantity.Text = total_quantity.ToString();
            priceWithoutTax.Text = total_price.ToString();
            total_price_tax = total_price * 13 / 100;
            tax.Text = total_price_tax.ToString();
            final_price = total_price + total_price_tax;
            finalPrice.Text = final_price.ToString();
        }

        protected void shoppingPage_Click(object sender, EventArgs e)
        {
            Response.Redirect("Products.aspx");
        }

        protected void refresh_Click(object sender, EventArgs e)
        {

            numberOfRows = GridView1.Rows.Count;
            total_price = 0;
            total_price_tax = 0;
            total_quantity = 0;
            final_price = 0;


            for (int i = 0; i < numberOfRows; i++)
            {
                //total_quantity += Int32.Parse(GridView1.Rows[i].Cells[3].Text);
                if (Int32.TryParse(GridView1.Rows[i].Cells[3].Text, out int quantity))
                {
                    total_quantity += quantity;
                }
                //total_price += Double.Parse(GridView1.Rows[i].Cells[5].Text)* Int32.Parse(GridView1.Rows[i].Cells[3].Text);
                if (Double.TryParse(GridView1.Rows[i].Cells[5].Text, out double price))
                {
                    total_price += price * quantity;
                }
            }

            totalQuantity.Text = total_quantity.ToString();
            priceWithoutTax.Text = total_price.ToString();
            total_price_tax = total_price * 13 / 100;
            tax.Text = total_price_tax.ToString();
            final_price = total_price + total_price_tax;
            finalPrice.Text = final_price.ToString();
        }

        protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
        {
            
        }

        protected void purchase_Click(object sender, EventArgs e)
        {
            numberOfRows = GridView1.Rows.Count;
            string product_name;
            string quantity;
            string company;
            string price;
            string category;
            // string user_name = Session["user_name"].ToString();
            string user_name = Session["user_name"].ToString();

            for (int i = 0; i < numberOfRows; i++)
            {
                product_name = GridView1.Rows[i].Cells[2].Text;
                quantity = GridView1.Rows[i].Cells[3].Text;
                company = GridView1.Rows[i].Cells[4].Text;
                price = GridView1.Rows[i].Cells[5].Text;
                category = GridView1.Rows[i].Cells[6].Text;

                string cs = Properties.Settings.Default.MyConnectionString;

                SqlConnection conn = new SqlConnection(cs);
                SqlCommand cmd = conn.CreateCommand();

                try
                {

                    string query = "insert into user_history values('"+user_name+"','"+product_name+"','"+quantity+"','"+price+"','"+category+"','"+company+"')";
                    cmd.CommandText = query;
                    conn.Open();
                    cmd.ExecuteNonQuery();
                }
                catch (Exception ex)
                {
                    Response.Write(ex.Message);
                }
                finally
                {
                    conn.Close();
                    cmd.Dispose();
                }

            }


            string cs2 = Properties.Settings.Default.MyConnectionString;
            SqlConnection conn2 = new SqlConnection(cs2);
            SqlCommand cmd2 = conn2.CreateCommand();

            try
            {

                string query = "delete from shopping_cart";
                cmd2.CommandText = query;
                conn2.Open();
                cmd2.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                Response.Write(ex.Message);
            }
            finally
            {
                conn2.Close();
                cmd2.Dispose();
            }



            Response.Redirect("Products.aspx");


        }
    }
}