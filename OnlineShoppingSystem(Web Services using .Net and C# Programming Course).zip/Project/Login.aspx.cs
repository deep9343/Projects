﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Project
{
    public partial class Login : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void LoginBtn_Click(object sender, EventArgs e)
        {

            try{
            string aname = Usertxt.Text;
            string pass = Passtxt.Text;
            string Role = DropDownList1.Text;
        
            if (Role=="Admin")
                {
                    string qry = "select * from Admin where AName='" + aname + "' and Password='" + pass + "'";
                    String myConnString = @"Data Source=.\SQLEXPRESS; Initial Catalog=Project; Integrated Security=True";

                    SqlConnection myConnection = new SqlConnection(myConnString);

                    SqlCommand myCmd = new SqlCommand(qry, myConnection);
                    Session["user_name"] = Usertxt.Text;
                    Response.Redirect("Admin.aspx");

                }
                else
                {
                    Label1.Text = "User ID and Password is not correct";
                }
            if (Role == "Users")
                {
                    string qry = "select * from Users where UsrName='" + aname + "' and Password='" + pass + "'";
                    String myConnString = @"Data Source=.\SQLEXPRESS; Initial Catalog=Project; Integrated Security=True";

                    SqlConnection myConnection = new SqlConnection(myConnString);

                    SqlCommand myCmd = new SqlCommand(qry, myConnection);
                    Session["user_name"] = Usertxt.Text;
                    Response.Redirect("Products.aspx");
                }

                
        }  
        catch(Exception ex)  
        {  
            Response.Write(ex.Message);  
        }
}

        protected void DropDownList1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        protected void RegisterBtn_Click(object sender, EventArgs e)
        {
            
            Response.Redirect("User.aspx");
        }
    }     
}