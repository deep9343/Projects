﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Project
{
    public partial class history : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            string selectAll = "select * from user_history where user_name='"+ Session["user_name"].ToString()+"'";
            SqlDataSource1.SelectCommand = selectAll;

        }

        protected void toProducts_Click(object sender, EventArgs e)
        {
            Response.Redirect("Products.aspx");
        }
    }
}