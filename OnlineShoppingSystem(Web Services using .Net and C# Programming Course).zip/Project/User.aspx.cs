﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;

namespace Project
{
    public partial class WebForm3 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void subbtn_Click(object sender, EventArgs e)
        {

            string first_name = TextBox1.Text;
            string last_name = TextBox2.Text;
            string user_name = TextBox3.Text;
            string pass = TextBox4.Text;
            string email = TextBox5.Text;
            string phone = TextBox6.Text;
            string address = TextBox7.Text;

            string cs = Properties.Settings.Default.MyConnectionString;

            SqlConnection conn = new SqlConnection(cs);
            SqlCommand cmd = conn.CreateCommand();

            try
            {

                string query = "insert into Users values('"+first_name+"','"+last_name+"','"+user_name+"','"+pass+"','"+email+"','"+phone+"','"+address+"')";
                cmd.CommandText = query;
                conn.Open();
                cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                Response.Write(ex.Message);
            }
            finally
            {
                conn.Close();
                cmd.Dispose();
            }
            
        }
    }
}