﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;

namespace Project
{
    public partial class WebForm2 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
           Label1.Text = "Welcome "+Session["user_name"].ToString()+" !";
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            Response.Redirect("editUser.aspx");
        }

        protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }


        protected void GridView1_SelectedIndexChanged1(object sender, EventArgs e)
        {            
                
                GridViewRow row = GridView1.SelectedRow;

                int selectId = Convert.ToInt32(row.Cells[0].Text);

            int product_id = Int32.Parse(row.Cells[0].Text);
            String product_name = row.Cells[3].Text;
            String category = row.Cells[1].Text;
            String company = row.Cells[2].Text;
            int price = Int32.Parse(row.Cells[4].Text);
            int quantity = Int32.Parse(row.Cells[5].Text);


            string cs = Properties.Settings.Default.MyConnectionString;

            SqlConnection conn = new SqlConnection(cs);
            SqlCommand cmd = conn.CreateCommand();

            try
            {

                string query = "insert into Shopping_cart values('" + product_name + "'," + quantity + ",'" + company + "'," + price + ",'" + category + "')";
                cmd.CommandText = query;
                conn.Open();
                cmd.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                Response.Write(ex.Message);
            }
            finally {
                conn.Close();
                cmd.Dispose();
            }
            
        }

        protected void checkout_Click(object sender, EventArgs e)
        {
            Response.Redirect("Checkout.aspx");
        }

        protected void searchButton_Click(object sender, EventArgs e)
        {
            string searchChoice = TextBox1.Text;
            string selectAll = "";
            if (searchChoice == "") {
                selectAll = "select * from Products";
            }
            else { 
                selectAll = "select * from Products where products like '"+searchChoice+"%'";
            }
            SqlDataSource2.SelectCommand = selectAll;

        }

        protected void TextBox1_TextChanged(object sender, EventArgs e)
        {
            
        }

        protected void viewHistory_Click(object sender, EventArgs e)
        {
            Response.Redirect("history.aspx");
        }

        protected void logOut_Click(object sender, EventArgs e)
        {
            Session.RemoveAll();
            Response.Redirect("Login.aspx");
        }
    }
}