﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Project
{
    public partial class Add_product : System.Web.UI.Page
    {
        String myConnString = @"Data Source=DC\SSERVER;Initial Catalog=Project;Integrated Security=True";

        private SqlCommand cmd;
        SqlConnection conn = new SqlConnection();

        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            string productname = TextBox1.Text;
            string category = TextBox2.Text;
            string company = TextBox3.Text;
            string price = TextBox4.Text;
            string quantity = TextBox5.Text;

          

        string query = "insert into Products values(@Categories,@Companies,@Products,@Prices,@Quantity)";
            string cs = Properties.Settings.Default.MyConnectionString;

            SqlConnection myConnection = new SqlConnection(cs);

        SqlCommand myCmd = new SqlCommand(query, myConnection);
        
            myCmd.Parameters.AddWithValue("@Products",productname);
            myCmd.Parameters.AddWithValue("@Categories", category);
            myCmd.Parameters.AddWithValue("@Companies", company);
            myCmd.Parameters.AddWithValue("@Prices", price);
            myCmd.Parameters.AddWithValue("@Quantity", quantity);
            myConnection.Open();
            int rowsInserted = myCmd.ExecuteNonQuery();
            myConnection.Close();
    }

        protected void toMainMenu_Click(object sender, EventArgs e)
        {
            Response.Redirect("Admin.aspx");
        }
    }
}